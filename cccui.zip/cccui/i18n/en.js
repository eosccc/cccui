'use strict';

module.exports = {
    current: 'Current language: ',
    create_language: 'New language',
    language: 'Language',
    create: 'Create',
    cancel: 'Cancel',
};