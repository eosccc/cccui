'use strict';

module.exports = {
    current: '当前语言：',
    create_language: '创建新语言',
    language: '语言名称',
    create: '创建',
    cancel: '取消',
};