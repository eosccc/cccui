const SpriteFrameSet = cc.Class({
    name: 'SpriteFrameSet',
    properties: {
        language: '',
        spriteFrame: cc.SpriteFrame
    }
});

module.exports = SpriteFrameSet;