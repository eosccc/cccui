

const PanelType = cc.Enum({
    Home: -1,
    Box: -1,
    NFT: -1,
    DeFi: -1,
    Shop: -1,
    Risk: -1,
});

cc.Class({
    extends: cc.Component,

    properties: {
        menuAnim: {
            default: null,
            type: cc.Animation
        },
        buyboxAnim: {
            default: null,
            type: cc.Animation
        },
        homeBtnGroups: {
            default: [],
            type: cc.Node
        },
    },

    // use this for initialization
    onLoad: function () {
        this.curPanel = PanelType.Home;
        this.menuAnim.play('menu_reset');
    },

    start: function () {
        cc.find("CCC").getComponent("CCCManager").setPlayGame(0);
        this.scheduleOnce ( function() {
            this.menuAnim.play('menu_intro');
        }.bind(this), 0.5);
        //cc.find("Canvas/Home/lower/main_btns/layout/btn_friends", this.node).node.x=0;

        //冒险后提示有武器盲盒
        this.scheduleOnce ( function() {
            var riskBoxLocal = cc.sys.localStorage.getItem('RiskBox');
            if(riskBoxLocal == 1){
                cc.find("Canvas/Home").getComponent("HomeUI").boxtipNode = cc.find("Canvas/lower/main_btns/layout/btn_box/tip");
                cc.find("Canvas/Home").getComponent("HomeUI").boxtipNode.active = true;
                cc.find("Canvas/Box/bot_frame/tab/tip").active = true;

                cc.sys.localStorage.setItem('RiskBox', 0);
            };
        }.bind(this), 5.5);
        

        //预加载下一个场景
        cc.director.preloadScene("PlayGame", function () {
            cc.log("Next scene preloaded");
        }); 
    },

    toggleHomeBtns: function (enable) {
        for (let i = 0; i < this.homeBtnGroups.length; ++i) {
            let group = this.homeBtnGroups[i];
            if (!enable) {
                cc.director.getScheduler().pauseTarget(group);
            } else {
                cc.director.getScheduler().resumeTarget(group);
            }
        }
        
    },



    gotoHome: function () {


        if (this.curPanel !== PanelType.Home) {
            if (this.curPanel === PanelType.Shop) {

                this.curPanel = PanelType.Home;
                this.scheduleOnce ( function() {
                    this.menuAnim.play('menu_intro');
                }.bind(this), 1.5);
            }else if (this.curPanel === PanelType.Box) {

                this.curPanel = PanelType.Home; 
                this.scheduleOnce ( function() {
                    this.menuAnim.play('menu_intro');
                }.bind(this), 1.5);
            }
        }
    },

    gotoKill: function () {
        //this.toggleActive(false);
        cc.director.loadScene('PlayGame');
    },

    buyBox1: function () {
        this.buyboxAnim.play('home_buybox');

        cc.find("CCC").getComponent("CCCManager").buybox(1);


        /* this.scheduleOnce ( function() {
            this.buyboxAnim.play('home_buybox1');
        }.bind(this), 3.5);
        this.scheduleOnce ( function() {
            this.menuAnim.play('menu_intro');

            this.boxtipNode = cc.find("Canvas/lower/main_btns/layout/btn_box/tip");
            this.boxtipNode.active = true;
        }.bind(this), 8.5); */

    },

    buyBox5: function () {
        this.buyboxAnim.play('home_buybox');

        cc.find("CCC").getComponent("CCCManager").buybox(5);

        /* this.scheduleOnce ( function() {
            this.buyboxAnim.play('home_buybox5');
        }.bind(this), 3.5);
        this.scheduleOnce ( function() {
            this.menuAnim.play('menu_intro');

            this.boxtipNode = cc.find("Canvas/lower/main_btns/layout/btn_box/tip");
            this.boxtipNode.active = true;
        }.bind(this), 6.5); */

    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
