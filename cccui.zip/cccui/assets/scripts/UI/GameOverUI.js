ScatterJS.plugins(new ScatterEOS());

let async = require("async");

var network = {
  blockchain: 'eos',
  protocol: 'https',
  host: 'eos.greymass.com',
  port: '443',
  chainId: 'aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906'
};
var dappName = 'cryptocycle';
var eos = null;
var account;
var scatter;
var requiredFields;
var eosOptions;

var UserData = {
    name: "eosio.null",
    eosToken: "0.0000 EOS",
    cccToken: "0.0000 CCC"
};

cc.Class({
    extends: cc.Component,

    properties: {
        num_score:cc.Node,
        num_kill:cc.Node,
        num_time:cc.Node
    },

    init (game) {
        this.game = game;
        this.hide();

        var networkLocal = cc.sys.localStorage.getItem('network');
        if(networkLocal){
          network = JSON.parse(networkLocal);
        };
        

        var userDataLocal = cc.sys.localStorage.getItem('userData');
        if(userDataLocal){UserData = JSON.parse(userDataLocal);};

        this.login();
    },

    login: function () {
        ScatterJS.scatter.connect(dappName).then(function (connected) {
  
            if (!connected) {
              console.log('connect to scatter failed.');
              return;
            } else {
              console.log('connected to scatter.');
            }
        
            scatter = ScatterJS.scatter;
              requiredFields = {accounts: [network]};
            
            scatter.getIdentity(requiredFields).then(function () {
        
        
              // var account = scatter.identity.accounts.find(x => x.blockchain === 'eos');
        
              account = scatter.identity.accounts[0];
              //console.log(account);
              //更新用户名
              UserData.name = account.name;
        
              eosOptions = {expireInSeconds: 60};
        
              eos = scatter.eos(network, Eos, eosOptions);
              //console.log(eos);
        
        
              //document.getElementById('login').classList.add('hide');
              //document.getElementById('userName').innerHTML = account.name;
              //console.log(account.name);
        
        
        
            }).catch(function (error) {
              // The user rejected this request, or doesn't have the appropriate requirements.
              console.log('connect to scatter failed.');
              console.log(error);
            });
          });
    },

    // use this for initialization
    show () {
        this.node.setPosition(0, 0);
    },

    hide () {
        this.node.x = 3000;
    },

    restart () {
        this.game.restart();
    },

    confirm () {
        cc.find("CCC").getComponent("CCCManager").risk ();
        //this.risk ();
        //cc.find("CCC").getComponent("CCCManager").play ();
    },

    async risk () {

        var score = parseInt(cc.sys.localStorage.getItem('score'));
        var round = parseInt(cc.sys.localStorage.getItem('curStage')) + 1;//数字如果是string会无法发起交易事务
  
        var params = [{account: 'weapbox.ccc',name: 'risk',authorization: [{actor: UserData.name,permission: 'active'}],data: {"user": UserData.name,"round": round,"score": score},}];
        //var params = [{account: 'htoken.ccc',name: 'update',authorization: [{actor: UserData.name,permission: 'active'}],data: {"owner": UserData.name,"id":111},}];
  
        //console.log(params);
        try {
          
          const result = await eos.transaction({actions: params});
              console.log(result);
  
              cc.director.loadScene('home');
  
              
        } catch (e) {
          console.log(e);
          //cc.find("Canvas/tipPanel").active = true;
          //cc.find("Canvas/tipPanel/content/tit").getComponent(cc.Label).string = "555";
          
          
        }
          
        
      },
});
