var poolData = {
    poolToken: "0.0001",
    defiToken: "0.0001",
    configs:null,
    userList:null, 
    poolConfig:null,
    wh_ratio:null,
    drtotalpower2:null,
    userpower2:null,
    bal_ratio:null,
    ccc_price:null,
    players:null,
  };

var mycom = '';

cc.Class({
    extends: cc.Component,

    properties: {
        

    },

    // use this for initialization
    init: function () {
        //this.home = home;
        //this.parentBtns = parentBtns;
    },

    show: function (event, customEventData) {

        var poolDataLocal = cc.sys.localStorage.getItem('poolData');
        if(poolDataLocal){poolData = JSON.parse(poolDataLocal);};


        var mytimes = 0;
        if (poolData.players[0].comtimes) {
            mytimes = poolData.players[0].comtimes;
          };
        cc.find("Canvas/comPanel/num_time").getComponent(cc.Label).string = mytimes;

        if (mytimes = 0) {
            cc.find("Canvas/comPanel/btn_confirm").active = false;
          };
        

        this.node.active = true;
        this.node.emit('fade-in');
    },

    send: function () {
        
        var mycom = cc.find("Canvas/comPanel/EditBox/TEXT_LABEL").getComponent(cc.Label).string;
        if(mycom){
            //console.log("mycom:"+mycom);
            cc.find("CCC").getComponent("CCCManager").sendCom(mycom);
        }
    },

    hide: function () {
        
        this.node.emit('fade-out');
    },
});
