// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html



cc.Class({
    extends: cc.Component,

    properties: {
        
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        
        //i18n.init('en');
        //console.log('lo');
        //console.log(this.i18n);
    },

    start () {

    },

    changeLanguage: function (event, customEventData) {
        this.i18n = require('LanguageData');
        if(customEventData===window.i18n.curLang) return;
        //console.log('change1');

        this.i18n.init(customEventData);

        this.i18n.updateSceneRenderers();

        window.i18n.curLang = customEventData;// 保存当前语言
        cc.sys.localStorage.setItem('curLang', customEventData);
    },

    // update (dt) {},
});
