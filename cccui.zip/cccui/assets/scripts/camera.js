const Camera = {
    max:1.2,
    min:1,
    idleTime:3
}
cc.Class({
    extends: cc.Component,

    properties: {
        mainCamera:cc.Camera
    },

        onLoad(){
            //路的边界

            this.canvas = cc.find("Canvas");
        },

        //更新摄像机位置
        updateCamera(dt){
            let x = this.mainCamera.node.x-this.node.x;
            let y = this.mainCamera.node.y-this.node.y;
            x = Math.abs(x)>100?x:0;
            y = Math.abs(y)>100?y:0;

            let x1 = this.mainCamera.node.x-x/60;
            let y1 = this.mainCamera.node.y-y/60;

            
            //就这样，摄像机就会跟随着主角移动了
            //把摄像机的座标设为主角一样
            this.mainCamera.node.x = x1;
            this.mainCamera.node.y = y1;            
        },


        update(dt){
            this.updateCamera(dt);
            //let w_pos = this.node.convertToWorldSpaceAR(cc.v2(0,0));
            //let n_pos = this.node.parent.convertToNodeSpaceAR(w_pos);
            //this.mainCamera.node.position = w_pos;
        },

});

