var BGPool = cc.Class({
    name: 'BGPool',
    properties: {
        bg: cc.SpriteFrame,
        bgcolor: cc.Color
    },
    ctor () {
        this.idx = 0;
        this.initList = [];
        this.list = [];
    },
    init () {
        var bgnode = cc.find("Canvas/root/bg");
        var com = bgnode.getComponent("cc.Sprite");
        com.spriteFrame = this.bg;
        //不知道为什么下面这两句一定要有,不然不显示效果
        bgnode.enabled=false;
        bgnode.enabled=true;

        var camnode = cc.find("Canvas/Main Camera");
        var cam = camnode.getComponent("cc.Camera");
        cam.backgroundColor = this.bgcolor;

        //cc.find("Canvas/root/bg").sprite.spriteFrame =this.bg;
        //cc.Camera.main.backgroundColor = cc.color(230, 23, 23, 255);
        //cc.find("Canvas/Main Camera").backgroundColor = this.bgcolor;
        //cc.find("Canvas/Main Camera").findCamera.backgroundColor.set(this.bgcolor);
        cc.log("bgc:"+this.bgcolor);
    },


});

module.exports = BGPool;