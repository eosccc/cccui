ScatterJS.plugins(new ScatterEOS());

let async = require("async");

var network = {
  blockchain: 'eos',
  protocol: 'https',
  host: 'eos.greymass.com',
  port: '443',
  chainId: 'aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906'
};
var dappName = 'cryptocycle';
var eos = null;
var account;
var scatter;
var requiredFields;
var eosOptions;
//var EosJs;



var UserData = {
    name: "eosio.null",
    eosToken: "0.0000 EOS",
    cccToken: "0.0000 CCC"
};

var poolData = {
  poolToken: "0.0001",
  defiToken: "0.0001",
  configs:null,
  userList:null, 
  poolConfig:null,
  wh_ratio:null,
  drtotalpower2:null,
  userpower2:null,
  bal_ratio:null,
  ccc_price:null,
  players:null,
};

var PlayGame = 0;//为1时在play game场景，不刷新ui的数据

var Nodes = ["eospush.tokenpocket.pro","api.eosflare.io","eos.greymass.com","api-mainnet.starteos.io","api.eosn.io","api.eossweden.se"];

var HeroboxSys = null;//herobox.ccc 表sys
//status	currentbid	price	increase	attime	lasttime

var BoxPrice = [];//['5.0000 EOS','5.0000 EOS','5.0000 EOS','5.0000 EOS','5.0000 EOS','25.0000 EOS'],最后一个为前5个的总值

var HeroBoxData = [];//英雄盲盒数据
var WeapBoxData = [];//武器盲盒数据

var HeroData = [];//英雄nft数据
var WeapData = [];//武器nft数据

var reserve0;//nftswap的交易对1的eos总数 //无法保存从链上get的数据，弃用
var reserve1;
var trade_fee = 90;
var protocol_fee = 10;
var swapPairData;
var swapHeroData;
var swapWeapData;
var userDefiData;//用户质押的插槽数据
var cccDefiHero;//defi质押的NFT数据
var cccDefiWeap;//defi质押的NFT数据

var MsgData;//公告messages



cc.Class({
    extends: cc.Component,

    properties: {
      upperNode: cc.Node,
      setPanelNode: cc.Node,
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
      //cc.game.addPersistRootNode(this.node);
    },

    start () {
        //var userData = JSON.parse(cc.sys.localStorage.getItem('userData'));
        //if(userData != null){UserData = userData;};
        //console.log(UserData.name);
        /* if(UserData.name == 'eosio.null'){
            console.log('yes');
            UserData = userData;
            //console.log(UserData.level);
        }; */

        var networkLocal = cc.sys.localStorage.getItem('network');
        if(networkLocal){
          network = JSON.parse(networkLocal);
          //如果有数据，需将单选选中对应节点
          var nodeIndex = Nodes.indexOf(network.host) + 1;
          var togname = "toggle"+nodeIndex.toString();
          //console.log(togname);
          this.setPanelNode.getChildByName("content").getChildByName("item2").getChildByName("ToggleContainer").getChildByName(togname).getComponent(cc.Toggle).isChecked = true;
          //console.log(this.setPanelNode.getChildByName("content").getChildByName("item2").getChildByName("ToggleContainer").getChildByName(togname));
        };
        

        var userDataLocal = cc.sys.localStorage.getItem('userData');
        if(userDataLocal){UserData = JSON.parse(userDataLocal);};
        this.setUserData(UserData);

        var poolDataLocal = cc.sys.localStorage.getItem('poolData');
        if(poolDataLocal){poolData = JSON.parse(poolDataLocal);};


        var MsgDataLocal = cc.sys.localStorage.getItem('MsgData');
        if(MsgDataLocal){MsgData = JSON.parse(MsgDataLocal);cc.find("CCC/upper/message").getComponent("message").setMsg(MsgData);};
        //MsgData = JSON.parse(MsgDataLocal);


        this.login();
        this.getChainData();




        this.getComponent("CCCManager").schedule(function() {
            // 每隔一段时间存储本地数据
            //if(UserData.name == 'eosio.null'){cc.sys.localStorage.setItem('userData', JSON.stringify(UserData));};
            cc.sys.localStorage.setItem('userData', JSON.stringify(UserData));
            cc.sys.localStorage.setItem('poolData', JSON.stringify(poolData));
        }, 25);

        this.getComponent("CCCManager").schedule(function() {
            // 每隔一段时间刷新数据
            
            if(this.PlayGame == 0){this.setUserData(UserData);};//如果在play game场景就不刷新
        }, 8);


    },

    getRequest: function () {//获取链接中可能存在的推荐人账号
      var url = location.search; //获取url中"?"符后的字串
      var theRequest = new Object();
      if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        var strs = str.split("&");
        for(var i = 0; i < strs.length; i ++) {
          theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
      }
      return theRequest;
    },

    setPlayGame: function (num) {
      this.PlayGame = num;
    },

    setUserData: function (userData) {
      

      //var ud = JSON.stringify(userData);//srting > json
      //var userData = JSON.parse(cc.sys.localStorage.getItem('userData'));
      this.upperNode.getChildByName("status_name").getChildByName("userName").getComponent(cc.Label).string = userData.name;
      this.upperNode.getChildByName("status_eos").getChildByName("num").getComponent(cc.Label).string = userData.eosToken;
      this.upperNode.getChildByName("status_ccc").getChildByName("num").getComponent(cc.Label).string = userData.cccToken;

      if(HeroboxSys){
        //如果系统暂停，就弹出提示框
        var tipPan = cc.find("Canvas/tipPanel");
        if((HeroboxSys.status== 0)&&(tipPan.active == false)){tipPan.getComponent("TipPanelUI").show(this,3)};

        //刷新盲盒价格
        cc.find("Canvas/Home/btn_buybox1/title").getComponent(cc.Label).string = BoxPrice[0];
        cc.find("Canvas/Home/btn_buybox5/title").getComponent(cc.Label).string = BoxPrice[5];
        cc.find("Canvas/Home/home_box/id").getComponent(cc.Label).string = HeroboxSys.currentbid;

      }

    },

    login: function () {
      ScatterJS.scatter.connect(dappName).then(function (connected) {

          if (!connected) {
            console.log('connect to scatter failed.');
            return;
          } else {
            console.log('connected to scatter.');
          }
      
          scatter = ScatterJS.scatter;
            requiredFields = {accounts: [network]};
          
          scatter.getIdentity(requiredFields).then(function () {
      
      
            // var account = scatter.identity.accounts.find(x => x.blockchain === 'eos');
      
            account = scatter.identity.accounts[0];
            //console.log(account);
            //更新用户名
            UserData.name = account.name;
      
            eosOptions = {expireInSeconds: 60};
      
            eos = scatter.eos(network, Eos, eosOptions);
            //console.log(eos);
      
      

      
      
          }).catch(function (error) {
            // The user rejected this request, or doesn't have the appropriate requirements.
            console.log('connect to scatter failed.');
            console.log(error);
          });
        });
  },

  getChainData: function () {
    //this.getCurrencyBalance({code:"eosio.token",coin:"EOS",account:"eoscccwallet"},);
    //JSON.stringify(userData.name)
    //console.log("getChainData");
    this.handleGetBalance();
    this.handleGetBox();
    this.handleGetHero();

    this.scheduleOnce ( function() {
      this.handleGetSwapHero();
      this.handleGetSwapPair();
    }.bind(this), 1);
    
    
  },



    /*
  * 获取eos账号余额
  * @params code
  * @params symbol
  * @params eosAccount
  * @return Balance
  */
    async getCurrencyBalance(obj, callback) {
      const params = {
        code: obj.code,
        symbol: obj.coin,
        account: obj.account || UserData.name
      };
      //console.log("get eos");
      if (!eos) {
        await this.login();
      }
      eos.getCurrencyBalance(params).then((results, error) => {
        if (results) {
          callback(results[0]);
          return
        }
        //callback(`${Number(0).toFixed(obj.decimal)} ${obj.coin}`);
      }).catch((e) => {
        // this.errorCall(e, callback);
      });
    },

    // 获取账户余额
    async handleGetBalance () {

      if (!eos) {
        await this.login();
        return;
      };

      try {
        var data = await eos.getCurrencyBalance("eosio.token",UserData.name,"EOS");
        UserData.eosToken = (!data[0]) ?  0.0000 : parseFloat(data[0]);
        //data.split(' ')[0];
        //console.log('eos:'+data[0]);  

        var data1 = await eos.getCurrencyBalance("eoscccdotcom",UserData.name,"CCC");
        UserData.cccToken = (!data1[0]) ?  0.0000 : parseFloat(data1[0]);
        //console.log('ccc:'+data1[0]); 

        var data2= await eos.getTableRows({json: true,code: 'herobox.ccc', scope: 'herobox.ccc',table: 'sys',limit: 1});
        //console.log(data2.rows[0]); 
        HeroboxSys = data2.rows[0];
        this.calBoxPrice();

        
      } catch (e) {
        console.log(e);
    
      }

    },

    // 获取pool余额
    async handleGetPoolBalance () {

      if (!eos) {
        await this.login();
        return;
      };

      try {
        var data1 = await eos.getCurrencyBalance("eoscccdotcom","cccdefi.ccc","CCC");
        poolData.defiToken = (!data1[0]) ?  0.0000 : parseFloat(data1[0]);

        var data2 = await eos.getCurrencyBalance("eoscccdotcom","cccpool.ccc","CCC");
        poolData.poolToken = (!data2[0]) ?  0.0000 : parseFloat(data2[0]);
        //console.log('ccc:'+data1[0]); 
        
      } catch (e) {
        console.log(e);
    
      }

    },

    // 获取pool数据
    async handleGetPoolData () {

      if (!eos) {
        await this.login();
        return;
      };

      try {
        var data3= await eos.getTableRows({json: true,code: 'cccdefi.ccc', scope: 'cccdefi.ccc',table: 'configs',limit: 1});
        //herospower weaponspower
        poolData.configs = data3.rows[0];

        var wpower = poolData.configs.weaponspower;

        if(wpower == 0){ wpower = 1;};
        if(poolData.configs){
          poolData.wh_ratio = poolData.configs.herospower / (wpower * 5);
          poolData.drtotalpower2 = poolData.configs.herospower + poolData.configs.weaponspower * poolData.wh_ratio;//换算后的系统总战力
        };
        
        
        var data4= await eos.getTableRows({json: true,code: 'cccdefi.ccc', scope: 'cccdefi.ccc',table: 'lists',lower_bound: UserData.name,upper_bound: UserData.name,limit: 1});
        //herospower	weaponspower	lasttime
        poolData.userList = data4.rows[0];
        if(poolData.userList && poolData.wh_ratio){
          poolData.userpower2 = poolData.userList.herospower + poolData.userList.weaponspower * poolData.wh_ratio;//换算后的用户总战力
          poolData.bal_ratio = poolData.userpower2 / poolData.drtotalpower2;
        };
        
        var data5= await eos.getTableRows({json: true,code: 'cccpool.ccc', scope: 'cccpool.ccc',table: 'config',limit: 1});
        //last_mine	rate
        poolData.poolConfig = data5.rows[0];

        var data6= await eos.getTableRows({json: true,code: 'swap.ccc', scope: 'swap.ccc',table: 'pairs',limit: 1});
        //last_mine	rate
        poolData.ccc_price = parseFloat(data6.rows[0].reserve0)/parseFloat(data6.rows[0].reserve1);
        
      } catch (e) {
        console.log(e);
    
      }

    },

    // 获取盲盒数据
    async handleGetBox () {

      if (!eos) {
        await this.login();
        return;
      };

      try {
        var data = await eos.getTableRows({json: true,code: 'herobox.ccc', scope: UserData.name,table: 'boxs',limit: 100});
        var data2 = await eos.getTableRows({json: true,code: 'weapbox.ccc', scope: UserData.name,table: 'boxs',limit: 100});
        //console.log(data.rows[0]); 
        HeroBoxData = data.rows;
        WeapBoxData = data2.rows;
        //cc.find("Canvas/Box").getComponent("BoxUI").HeroBoxData = data.rows[0];
        cc.sys.localStorage.setItem('HeroBoxData', JSON.stringify(HeroBoxData));
        cc.sys.localStorage.setItem('WeapBoxData', JSON.stringify(WeapBoxData));
        
      } catch (e) {
        console.log(e);
    
      }

    },



  changeNode: function (event, customEventData) {
    if(network.host === Nodes[parseInt(customEventData)]) return;

    network.host = Nodes[parseInt(customEventData)];

// 保存
    cc.sys.localStorage.setItem('network', JSON.stringify(network));
    //console.log("change node");

},

  // 使小数点后面不足4位数补0
  formatnumber: function (value, num){
         var a, b, c, i;
         a = value.toString();
         b = a.indexOf(".");
         c = a.length;
         if (num == 0) {
             if (b != -1) {
                 a = a.substring(0, b);
             }
         } else {//如果没有bai小数点
             if (b == -1) {
                 a = a + ".";
                 for (i = 1; i <= num; i++) {
                     a = a + "0";
                 }
             } else {//有小数点，超出位数自动截取，否则补0
                 a = a.substring(0, b + num + 1);
                 for (i = c; i <= b + num; i++) {
                     a = a + "0";
                 }
             }
         }
         return a;
     },
    //formatnumber(3.1,4);//使用方法，第一个参数是你要转化的小数，第二个是位数



    update (dt) {
        //
        //UserData.level += dt;
    },
});
