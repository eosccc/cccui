cc.Class({
    extends: cc.Component,

    properties: {

    },

    // use this for initialization
    init: function () {
        //this.home = home;
        //this.parentBtns = parentBtns;
    },

    show: function () {
        this.node.active = true;
        this.node.emit('fade-in');
        //this.home.toggleHomeBtns(false);
        //cc.director.getScheduler().pauseTarget(this.parentBtns);
        let suc = cc.find("Canvas/heroPanel/success");
        if(suc && suc.active){
            cc.tween(suc).to(1, {scale: 3}).by(1, {scale: 1}).to(1, {scale: 1}).start();
        };

        let suc2 = cc.find("Canvas/weapPanel/success");
        if(suc2 && suc2.active){
            cc.tween(suc2).to(1, {scale: 3}).by(1, {scale: 1}).to(1, {scale: 1}).start();
        };

        
    },

    hide: function () {
        this.node.emit('fade-out');

        //hero面板去掉科技感光线特效
        cc.find("Canvas/heroPanel/fx/bg_eff1").active = false;
        cc.find("Canvas/heroPanel/fx/bg_eff2").active = false;
        cc.find("Canvas/heroPanel/fx/bg_eff3").active = false;
        cc.find("Canvas/heroPanel/success").active = false;

        cc.find("Canvas/weapPanel/fx/bg_eff1").active = false;
        cc.find("Canvas/weapPanel/fx/bg_eff2").active = true;
        cc.find("Canvas/weapPanel/fx/bg_eff3").active = false;
        cc.find("Canvas/weapPanel/success").active = false;
        //this.home.toggleHomeBtns(true);
        //cc.director.getScheduler().resumeTarget(this.parentBtns);
    },
});
