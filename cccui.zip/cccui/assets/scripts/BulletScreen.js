var bullets = [];

cc.Class({
    extends: cc.Component,

    properties: {
        bulletPrefab: cc.Prefab
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        // 确保在不同机型下该节点都与屏幕大小一致
        this.node.width = cc.Canvas.instance.node.width;
        this.node.height = cc.Canvas.instance.node.height;

        var bulletsLocal = cc.sys.localStorage.getItem('Bullets');
        if(bulletsLocal){bullets = JSON.parse(bulletsLocal);};
     
        // 当前出现在屏幕上的弹幕数组
        this.bulletsArray = [];
    },

    start () {
        var round = parseInt(cc.sys.localStorage.getItem('curStage')) + 1;

        cc.find("CCC").getComponent("CCCManager").schedule(function() {
            // 每隔一段时间获取链上数据
            cc.find("CCC").getComponent("CCCManager").handleGetComments(round);
            var bulletsLocal = cc.sys.localStorage.getItem('Bullets');
            if(bulletsLocal){bullets = JSON.parse(bulletsLocal);};
        }, 17);

    },

    spawnBullets () {
        // 生成提示文本,决定了每次生成的弹幕数量、内容、颜色、速度以及生成位置
        let num = Math.round(Math.random()*4);      // 决定生成的数量
     
        for (let i=0; i<num; i++) {
            let bullet = cc.instantiate(this.bulletPrefab);
            this.bulletsArray.push(bullet);
            this.node.addChild(bullet);
            bullet.x = this.node.width * 1.5;
            bullet.getComponent(cc.Label).string = this.randomContent();
            bullet.color = this.randomColor();
            bullet.speed = this.randomSpeed();
            bullet.y = this.randomStartPosY();
        }
    },

    randomColor () {
        // 文本颜色随机
        let red = Math.round(Math.random()*255);
        let green = Math.round(Math.random()*255);
        let blue = Math.round(Math.random()*255);
        return new cc.Color(red, green, blue);
    },
     
    randomContent () {
        // 文本内容随机
        let index = Math.round(Math.random()*(bullets.length-1));
        //let bullet = bullets[index].player + ":" +bullets[index].comment;
        let bullet = bullets[index].comment;
        return bullet;
    },
     
    randomSpeed () {
        // 移动速度随机
        let speed = Math.round(Math.random()*100) + 50;
        return speed;
    },
     
    randomStartPosY () {
        // 初始y坐标随机
        let height = this.node.height;
        let y = Math.round(Math.random()*height*0.2) + height*0.7;
        return y;
    },

    start () {
        var round = parseInt(cc.sys.localStorage.getItem('curStage')) + 1;

        cc.find("CCC").getComponent("CCCManager").schedule(function() {
            // 每隔一段时间获取链上数据
            cc.find("CCC").getComponent("CCCManager").handleGetComments(round);
            var bulletsLocal = cc.sys.localStorage.getItem('Bullets');
            if(bulletsLocal){bullets = JSON.parse(bulletsLocal);};
        }, 17);

    },

    update (dt) {
        let record = [];
        for (let i=0; i<this.bulletsArray.length; i++) {
            this.bulletsArray[i].x -= dt*this.bulletsArray[i].speed;
     
            // 文本完全移动到屏幕左侧后，回收
            if (this.bulletsArray[i].x <= -(this.node.width/2 + this.bulletsArray[i].width)) {
                this.bulletsArray[i].removeFromParent();
                record.push(i);
            }
        }
     
        // 删除已完成移动的文本元素
        for (let i=0; i<record.length; i++) {
            this.bulletsArray.splice(record[i], 1);
        }
     
        // 当前所有提示文本消失后，重新生成
        if (this.bulletsArray.length == 0) {
            let trigger = Math.random();
            if (trigger>0.99) 
                {this.spawnBullets();}
        }
    },
    
});
