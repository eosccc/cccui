var tipDate = [
    {"tit":"tip_nonetit","des":"tip_none"},
    {"tit":"info_pricetit","des":"info_price"},
    {"tit":"nav_store","des":"nav_risk"},
    {"tit":"tip_systoptit","des":"tip_systop"},
    {"tit":"tip_failtit","des":"tip_fail"},
    {"tit":"tip_selltit","des":"tip_sell"},
    {"tit":"tip_claimtit","des":"tip_claim"},
    {"tit":"tip_unstaketit","des":"tip_unstake"},
    {"tit":"tip_staketit","des":"tip_stake"},
    {"tit":"tip_pooltit","des":"tip_pool"},
    {"tit":"tip_pomelotit","des":"tip_pomelo"},
    {"tit":"tip_risktit","des":"tip_risk"},
    {"tit":"tip_comtit","des":"tip_com"}
];

cc.Class({
    extends: cc.Component,

    properties: {
        labelTitle: {
            default: null,
            type: cc.Label
        },
        labelDes: {
            default: null,
            type: cc.Label
        }

    },

    // use this for initialization
    init: function () {
        //this.home = home;
        //this.parentBtns = parentBtns;
    },

    show: function (event, customEventData) {
        this.labelTitle.getComponent("LocalizedLabel").dataID = tipDate[parseInt(customEventData)].tit;
        this.labelDes.getComponent("LocalizedLabel").dataID = tipDate[parseInt(customEventData)].des;

        this.node.active = true;
        this.node.emit('fade-in');
    },

    hide: function () {
        cc.find("Canvas/tipPanel/error").getComponent(cc.Label).string = '';
        this.node.emit('fade-out');
    },
});
