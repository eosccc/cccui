var userRiskData = [];//用户质押的nft数据

cc.Class({
    extends: cc.Component,

    properties: {
        player: cc.Node,
        inGameUI: cc.Node,
        playerFX: cc.Node,
        waveMng: cc.Node,
        bossMng: cc.Node,
        poolMng: cc.Node,
        foeGroup: cc.Node,
        gameOverUI: cc.Node,
        cameraRoot: cc.Animation
    },

    // use this for initialization
    onLoad () {
        this.playerFX = this.playerFX.getComponent('PlayerFX');
        this.playerFX.init(this);
        this.player = this.player.getComponent('Player');
        this.player.init(this);
        this.player.node.active = false;
        this.poolMng = this.poolMng.getComponent('PoolMng');
        this.poolMng.init();
        this.waveMng = this.waveMng.getComponent('WaveMng');
        this.waveMng.init(this);
        this.bossMng = this.bossMng.getComponent('BossMng');
        this.bossMng.init(this);
        this.sortMng = this.foeGroup.getComponent('SortMng');
        this.sortMng.init();

        this.starttime = 0;

        var userDefiDataLocal = cc.sys.localStorage.getItem('userDefiData');
        if(userDefiDataLocal){
            cc.sys.localStorage.setItem('userRiskData', userDefiDataLocal);//区别于userDefiData，可以删除userRiskData中失败的hero和weap
            userRiskData = JSON.parse(userDefiDataLocal);
        };
        cc.find("Canvas/root/InGameUI/txt_life").getComponent(cc.Label).string = userRiskData.length;
    },

    start () {
        this.playerFX.playIntro();
        // UI initialization
        this.inGameUI = this.inGameUI.getComponent('InGameUI');
        this.inGameUI.init(this);
        //this.deathUI = this.deathUI.getComponent('DeathUI');
        //this.deathUI.init(this);
        this.gameOverUI = this.gameOverUI.getComponent('GameOverUI');
        this.gameOverUI.init(this);

        this.starttime = Math.round(new Date().getTime()/1000);

        this.newHero ();
        
    },

    newHero () {

        if((userRiskData[0].hero)[0] != undefined ){
            this.player.updateHero(userRiskData[0]);
            
        }else {
            cc.director.loadScene('home');
        }
        
    },

    pause () {
        let scheduler = cc.director.getScheduler();
        scheduler.pauseTarget(this.waveMng);
        this.sortMng.enabled = false;
    },

    resume () {
        let scheduler = cc.director.getScheduler();
        scheduler.resumeTarget(this.waveMng);
        this.sortMng.enabled = true;
    },
    
    cameraShake () {
        this.cameraRoot.play('camera-shake');  
    },

    death () {
        //this.gameOverUI.show();
        //this.pause();
        userRiskData.shift();
        cc.sys.localStorage.setItem('userRiskData', JSON.stringify(userRiskData));

        cc.find("Canvas/root/InGameUI/txt_life").getComponent(cc.Label).string = userRiskData.length;

        if(userRiskData[0] != undefined ){
            this.player.updateHero(userRiskData[0]);
            this.revive();
            //this.clearAllFoes();
            
        }else {
            //cc.director.loadScene('home');
            this.gameOver();
        }

        

    },

    revive () {
        //this.deathUI.hide();
        this.playerFX.playRevive();
        this.player.revive();
    },
    
    clearAllFoes () {
        let nodeList = this.foeGroup.children;
        for (let i = 0; i < nodeList.length; ++i) {
            let foe = nodeList[i].getComponent('Foe');
            if (foe) {
                foe.dead();                
            } else {
                let projectile = nodeList[i].getComponent('Projectile');
                if (projectile) {
                    projectile.broke();                    
                }
            }
        }
    },

    playerReady: function () {
        this.resume();
        this.waveMng.startWave();
        this.player.node.active = true;
        this.player.ready();
    },

    gameOver: function () {
        //this.deathUI.hide();
        var timeLeft = Math.round(new Date().getTime()/1000) - this.starttime;
        var kills = cc.sys.localStorage.getItem('kills');
        var score = parseInt(kills) + Math.floor(timeLeft / 3);
        if(score > 65500){score = 65500;};

        cc.sys.localStorage.setItem('score', score);

        this.gameOverUI.num_score.getComponent(cc.Label).string = score;

        this.gameOverUI.num_kill.getComponent(cc.Label).string = kills;

        this.gameOverUI.num_time.getComponent(cc.Label).string = Math.floor(timeLeft/60).toString() + "'" + (timeLeft%60 < 10 ? '0' : '') + timeLeft%60;

        this.gameOverUI.show();
        
        this.pause();
    },

    restart: function () {
        cc.director.loadScene('PlayGame');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
