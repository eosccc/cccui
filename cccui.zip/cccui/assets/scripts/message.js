cc.Class({

    extends: cc.Component,
    
     
    
    properties: {
    
    marqueeLabel:cc.Label,
    
    mask: cc.Node
    
    },
    
     
    
    onLoad: function(){
    
    //this.desc1 = "Crypto Cycle starts the public test."
    
    //this.desc2 = "Crypto Cycle 開啓公測。"
    
    //this.desc3 = "3"
    
    this.descs = []
    
    //this.descs.unshift(this.desc1)
    
    //this.descs.unshift(this.desc2)
    
    //this.descs.unshift(this.desc3)
    
     
    
    this.marqeeIndex = 0;
    
    this.marqueeBg = this.node;
    
    this.marqueeBg.opacity = 0;
    
    },

    setMsg: function(messages){

        //this.desc1 = messages[0];
        //this.desc2 = messages[1];
        this.descs = messages;

    },
    
    update: function(){
    
    try{
    
    var endIndex = this.descs.length - 1
    
    var desc = this.descs[endIndex]
    
    if(desc){
    
    this.runMarqeeBar(desc)
    
    this.descs[endIndex] = null;
    
    }
    
    }catch(e){
    
    }
    
    },
    
     
    
    runMarqeeBar: function(desc){
    
    this.marqueeBg.opacity = 255;
    
    this.marqueeLabel.node.x = this.mask.width;
    
    this.marqueeLabel.string = desc;
    
    this.marqueeLabel.node.runAction(cc.sequence(
    
    cc.moveTo(30, -this.marqueeLabel.node.width, 0),
    
    cc.callFunc(()=>{
    
    this.descs.pop();
    
    if(!this.isExistContent()){
    
    this.descs.unshift(this.desc1)
    
    // this.marqueeBg.opacity = 0;
    
    }
    
    }, this, this)))
    
    },
    
     
    
    isExistContent: function(){
    
    if (this.descs[this.descs.length - 1]){
    
    return true;
    
    }
    
    return false;
    
    }
    
    });