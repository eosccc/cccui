

cc.Class({
    extends: cc.Component,

    properties: {
        bg: {
            default: null,
            type: cc.Sprite
        },
        title: {
            default: null,
            type: cc.Label
        },
        num: {
            default: null,
            type: cc.Label
        },
        bgs: {
            default: [],
            type: cc.SpriteFrame
        },
        titles: {
            default: [],
            type: cc.String
        },
        dbbutton: {
            default: null,
            type: cc.Button
        },
    },

    // use this for initialization
    onLoad: function () {
        
        //this.refresh();
    },

    updateStage(i){
        this.bg.spriteFrame = this.bgs[i];
        this.num.string = i + 1;
        this.title.string = this.titles[i];


    },


    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
